/* =====================================================================
   PRY2204 - Modelamiento de Bases de Datos
   Evaluación Final Transversal (EFT) - Semana 9
   Caso: ANFP - Asociación Nacional de Fútbol Profesional
   Estudiante: Satcha Quispe Parada
   Carrera: Analista Programador Computacional
   Profesor: Eithel Klauss Patricio González Rojas
   Usuario/Conexión: PRY2204_S9 (Oracle 19c XE o superior / Cloud)

   Contenido del Script:
     0. Limpieza previa de objetos (Drop seguro para re-ejecución)
     1. Creación de tablas según orden de dependencia (Fase 3)
     2. Secuencia para CLUB_FUTBOL (inicia en 703, incremento de 4)
     3. Poblamiento secuencial de datos según Figura 2 (REGION, COMUNA,
        ASOCIACION, NACIONALIDAD, CLUB_FUTBOL)
     4. Consultas SELECT de recuperación de datos (Fase 4: Informe 1 e 2)
   ===================================================================== */

/* ---------------------------------------------------------------------
   0. LIMPIEZA PREVIA DE TABLAS Y SECUENCIAS
   --------------------------------------------------------------------- */
BEGIN
    FOR t IN (SELECT table_name FROM user_tables
               WHERE table_name IN ('JUGADOR_IDIOMA','JUGADOR_CLUB','PERSONAL_PLANTA',
                                    'JUGADOR','TRABAJADOR','IDIOMA','PUESTO',
                                    'CLUB_FUTBOL','ESCUELA_FUTBOL','ASOCIACION',
                                    'NACIONALIDAD','ESTADO_CIVIL','COMUNA','REGION'))
    LOOP
        EXECUTE IMMEDIATE 'DROP TABLE ' || t.table_name || ' CASCADE CONSTRAINTS PURGE';
    END LOOP;
    FOR s IN (SELECT sequence_name FROM user_sequences
               WHERE sequence_name = 'SEQ_CLUB_FUTBOL')
    LOOP
        EXECUTE IMMEDIATE 'DROP SEQUENCE ' || s.sequence_name;
    END LOOP;
END;
/

/* ---------------------------------------------------------------------
   1. CREACIÓN DE TABLAS Y RESTRICCIONES (FASE 3)
   1.1 Tablas maestras independientes (sin claves foráneas)
   --------------------------------------------------------------------- */

-- 1.1.1 REGION
CREATE TABLE region (
    id_region      NUMBER(2)    NOT NULL,
    nombre_region  VARCHAR2(50) NOT NULL
);
ALTER TABLE region ADD CONSTRAINT region_pk PRIMARY KEY (id_region);
ALTER TABLE region ADD CONSTRAINT region_nombre_un UNIQUE (nombre_region);

-- 1.1.2 ESTADO_CIVIL
CREATE TABLE estado_civil (
    id_estado_civil  NUMBER(2)    NOT NULL,
    descripcion      VARCHAR2(20) NOT NULL
);
ALTER TABLE estado_civil ADD CONSTRAINT estado_civil_pk PRIMARY KEY (id_estado_civil);
ALTER TABLE estado_civil ADD CONSTRAINT estado_civil_desc_un UNIQUE (descripcion);

-- 1.1.3 NACIONALIDAD (PK generada mediante IDENTITY: inicia en 210 e incrementa de 2 en 2)
CREATE TABLE nacionalidad (
    id_nacion    NUMBER(3) GENERATED ALWAYS AS IDENTITY
                 (START WITH 210 INCREMENT BY 2 NOCACHE) NOT NULL,
    descripcion  VARCHAR2(30) NOT NULL
);
ALTER TABLE nacionalidad ADD CONSTRAINT nacionalidad_pk PRIMARY KEY (id_nacion);
ALTER TABLE nacionalidad ADD CONSTRAINT nacionalidad_desc_un UNIQUE (descripcion);

-- 1.1.4 ASOCIACION
CREATE TABLE asociacion (
    id_asociacion      NUMBER(3)    NOT NULL,
    nombre_asociacion  VARCHAR2(60) NOT NULL,
    fecha_creacion     DATE         NOT NULL,
    tipo_asociacion    CHAR(1)      NOT NULL
);
ALTER TABLE asociacion ADD CONSTRAINT asociacion_pk PRIMARY KEY (id_asociacion);
-- Condición: La fecha de creación debe ser igual o posterior al 31 de diciembre de 1980
ALTER TABLE asociacion ADD CONSTRAINT asociacion_fecha_ck
    CHECK (fecha_creacion >= TO_DATE('31-12-1980','DD-MM-YYYY'));
-- P = Profesional, A = Amateur
ALTER TABLE asociacion ADD CONSTRAINT asociacion_tipo_ck
    CHECK (tipo_asociacion IN ('P','A'));

-- 1.1.5 ESCUELA_FUTBOL
CREATE TABLE escuela_futbol (
    id_escuela        NUMBER(4)    NOT NULL,
    nombre_escuela    VARCHAR2(60) NOT NULL,
    capacidad         NUMBER(6)    NOT NULL,
    fecha_fundacion   DATE         NOT NULL
);
ALTER TABLE escuela_futbol ADD CONSTRAINT escuela_futbol_pk PRIMARY KEY (id_escuela);
ALTER TABLE escuela_futbol ADD CONSTRAINT escuela_futbol_cap_ck CHECK (capacidad > 0);

-- 1.1.6 CLUB_FUTBOL (Código generado con secuencia SEQ_CLUB_FUTBOL; nombre de club único)
CREATE TABLE club_futbol (
    id_club          NUMBER(5)    NOT NULL,
    nombre_club      VARCHAR2(60) NOT NULL,
    patrimonio       NUMBER(12)   DEFAULT 0 NOT NULL,
    ubicacion_calle  VARCHAR2(60) NOT NULL,
    tipo_club        VARCHAR2(12) DEFAULT 'Profesional' NOT NULL
);
ALTER TABLE club_futbol ADD CONSTRAINT club_futbol_pk PRIMARY KEY (id_club);
-- Condición: El nombre del club registrado en CLUB_FUTBOL debe ser único
ALTER TABLE club_futbol ADD CONSTRAINT club_futbol_nombre_un UNIQUE (nombre_club);
ALTER TABLE club_futbol ADD CONSTRAINT club_futbol_patrim_ck CHECK (patrimonio >= 0);
ALTER TABLE club_futbol ADD CONSTRAINT club_futbol_tipo_ck
    CHECK (tipo_club IN ('Profesional','Amateur'));

-- 1.1.7 PUESTO
CREATE TABLE puesto (
    id_puesto      NUMBER(2)    NOT NULL,
    nombre_puesto  VARCHAR2(30) NOT NULL
);
ALTER TABLE puesto ADD CONSTRAINT puesto_pk PRIMARY KEY (id_puesto);
ALTER TABLE puesto ADD CONSTRAINT puesto_nombre_un UNIQUE (nombre_puesto);

-- 1.1.8 IDIOMA
CREATE TABLE idioma (
    id_idioma      NUMBER(3)    NOT NULL,
    nombre_idioma  VARCHAR2(40) NOT NULL
);
ALTER TABLE idioma ADD CONSTRAINT idioma_pk PRIMARY KEY (id_idioma);
ALTER TABLE idioma ADD CONSTRAINT idioma_nombre_un UNIQUE (nombre_idioma);

/* ---------------------------------------------------------------------
   1.2 Tablas con claves foráneas hacia las entidades anteriores
   --------------------------------------------------------------------- */

-- 1.2.1 COMUNA
CREATE TABLE comuna (
    id_comuna      NUMBER(5)    NOT NULL,
    nombre_comuna  VARCHAR2(50) NOT NULL,
    id_region      NUMBER(2)    NOT NULL
);
ALTER TABLE comuna ADD CONSTRAINT comuna_pk PRIMARY KEY (id_comuna);
ALTER TABLE comuna ADD CONSTRAINT comuna_region_fk
    FOREIGN KEY (id_region) REFERENCES region (id_region);

-- 1.2.2 TRABAJADOR (Supertipo con datos comunes de jugadores y personal de planta)
CREATE TABLE trabajador (
    num_inscripcion   NUMBER(9)    NOT NULL,
    rut_trabajador    NUMBER(8)    NOT NULL,
    dv_rut            CHAR(1)      NOT NULL,
    nombres           VARCHAR2(50) NOT NULL,
    apellidos         VARCHAR2(60) NOT NULL,
    sueldo_base       NUMBER(9)    DEFAULT 0 NOT NULL,
    fecha_nacimiento  DATE         NOT NULL,
    genero            CHAR(1)      NOT NULL,
    telefono_movil    VARCHAR2(15) NOT NULL,
    email             VARCHAR2(50),
    direccion         VARCHAR2(80) NOT NULL,
    id_comuna         NUMBER(5)    NOT NULL,
    id_estado_civil   NUMBER(2)    NOT NULL,
    id_nacion         NUMBER(3)    NOT NULL
);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_pk PRIMARY KEY (num_inscripcion);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_rut_un UNIQUE (rut_trabajador);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_dv_ck
    CHECK (dv_rut IN ('0','1','2','3','4','5','6','7','8','9','K'));
ALTER TABLE trabajador ADD CONSTRAINT trabajador_sueldo_ck CHECK (sueldo_base >= 0);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_genero_ck
    CHECK (genero IN ('M','F','O'));
ALTER TABLE trabajador ADD CONSTRAINT trabajador_comuna_fk
    FOREIGN KEY (id_comuna) REFERENCES comuna (id_comuna);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_estado_civil_fk
    FOREIGN KEY (id_estado_civil) REFERENCES estado_civil (id_estado_civil);
ALTER TABLE trabajador ADD CONSTRAINT trabajador_nacionalidad_fk
    FOREIGN KEY (id_nacion) REFERENCES nacionalidad (id_nacion);

/* ---------------------------------------------------------------------
   1.3 Subtipos de TRABAJADOR (Especialización: PK es FK a TRABAJADOR)
   --------------------------------------------------------------------- */

-- 1.3.1 JUGADOR (Subtipo de TRABAJADOR)
CREATE TABLE jugador (
    num_inscripcion      NUMBER(9)  NOT NULL,
    id_puesto            NUMBER(2)  NOT NULL,
    monto_total_premios  NUMBER(12) DEFAULT 0 NOT NULL,
    id_asociacion        NUMBER(3)  NOT NULL,
    id_escuela           NUMBER(4),            -- opcional: puede no provenir de escuela
    anio_fin_amateur     NUMBER(4)             -- opcional: año de salida del amateurismo
);
ALTER TABLE jugador ADD CONSTRAINT jugador_pk PRIMARY KEY (num_inscripcion);
ALTER TABLE jugador ADD CONSTRAINT jugador_premios_ck CHECK (monto_total_premios >= 0);
-- Si registra escuela, debe registrar año de fin del amateurismo (y viceversa)
ALTER TABLE jugador ADD CONSTRAINT jugador_escuela_anio_ck
    CHECK ((id_escuela IS NULL AND anio_fin_amateur IS NULL)
        OR (id_escuela IS NOT NULL AND anio_fin_amateur IS NOT NULL));
ALTER TABLE jugador ADD CONSTRAINT jugador_anio_ck
    CHECK (anio_fin_amateur IS NULL OR anio_fin_amateur >= 1900);
ALTER TABLE jugador ADD CONSTRAINT jugador_trabajador_fk
    FOREIGN KEY (num_inscripcion) REFERENCES trabajador (num_inscripcion);
ALTER TABLE jugador ADD CONSTRAINT jugador_puesto_fk
    FOREIGN KEY (id_puesto) REFERENCES puesto (id_puesto);
ALTER TABLE jugador ADD CONSTRAINT jugador_asociacion_fk
    FOREIGN KEY (id_asociacion) REFERENCES asociacion (id_asociacion);
ALTER TABLE jugador ADD CONSTRAINT jugador_escuela_fk
    FOREIGN KEY (id_escuela) REFERENCES escuela_futbol (id_escuela);

-- 1.3.2 PERSONAL_PLANTA (Subtipo de TRABAJADOR)
CREATE TABLE personal_planta (
    num_inscripcion   NUMBER(9)   NOT NULL,
    id_club           NUMBER(5)   NOT NULL,
    horas_trabajadas  NUMBER(5,1),             -- opcional (cuando corresponda)
    valor_hora_extra  NUMBER(8)                -- opcional (cuando corresponda)
);
ALTER TABLE personal_planta ADD CONSTRAINT personal_planta_pk PRIMARY KEY (num_inscripcion);
ALTER TABLE personal_planta ADD CONSTRAINT personal_planta_horas_ck
    CHECK (horas_trabajadas IS NULL OR horas_trabajadas >= 0);
ALTER TABLE personal_planta ADD CONSTRAINT personal_planta_hextra_ck
    CHECK (valor_hora_extra IS NULL OR valor_hora_extra >= 0);
ALTER TABLE personal_planta ADD CONSTRAINT personal_planta_trabajador_fk
    FOREIGN KEY (num_inscripcion) REFERENCES trabajador (num_inscripcion);
ALTER TABLE personal_planta ADD CONSTRAINT personal_planta_club_fk
    FOREIGN KEY (id_club) REFERENCES club_futbol (id_club);

/* ---------------------------------------------------------------------
   1.4 Tablas de asociación N:M (Claves Primarias Compuestas)
   --------------------------------------------------------------------- */

-- 1.4.1 JUGADOR_CLUB (Historial de permanencia en clubes a lo largo del tiempo)
CREATE TABLE jugador_club (
    num_inscripcion  NUMBER(9) NOT NULL,
    id_club          NUMBER(5) NOT NULL,
    fecha_inicio     DATE      DEFAULT SYSDATE NOT NULL,
    fecha_fin        DATE
);
ALTER TABLE jugador_club ADD CONSTRAINT jugador_club_pk
    PRIMARY KEY (num_inscripcion, id_club, fecha_inicio);
ALTER TABLE jugador_club ADD CONSTRAINT jugador_club_fechas_ck
    CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio);
ALTER TABLE jugador_club ADD CONSTRAINT jugador_club_jugador_fk
    FOREIGN KEY (num_inscripcion) REFERENCES jugador (num_inscripcion);
ALTER TABLE jugador_club ADD CONSTRAINT jugador_club_club_fk
    FOREIGN KEY (id_club) REFERENCES club_futbol (id_club);

-- 1.4.2 JUGADOR_IDIOMA (Idiomas que domina el jugador y nivel de dominio)
CREATE TABLE jugador_idioma (
    num_inscripcion  NUMBER(9)    NOT NULL,
    id_idioma        NUMBER(3)    NOT NULL,
    nivel_dominio    VARCHAR2(15) DEFAULT 'BASICO' NOT NULL
);
ALTER TABLE jugador_idioma ADD CONSTRAINT jugador_idioma_pk
    PRIMARY KEY (num_inscripcion, id_idioma);
ALTER TABLE jugador_idioma ADD CONSTRAINT jugador_idioma_nivel_ck
    CHECK (nivel_dominio IN ('BASICO','INTERMEDIO','AVANZADO','NATIVO'));
ALTER TABLE jugador_idioma ADD CONSTRAINT jugador_idioma_jugador_fk
    FOREIGN KEY (num_inscripcion) REFERENCES jugador (num_inscripcion);
ALTER TABLE jugador_idioma ADD CONSTRAINT jugador_idioma_idioma_fk
    FOREIGN KEY (id_idioma) REFERENCES idioma (id_idioma);

/* ---------------------------------------------------------------------
   2. SECUENCIA PARA CLUB_FUTBOL (FASE 3)
   Comienza en 703 y se incrementa de 4 en 4
   --------------------------------------------------------------------- */
CREATE SEQUENCE seq_club_futbol
    START WITH 703
    INCREMENT BY 4
    NOCACHE
    NOCYCLE;

/* ---------------------------------------------------------------------
   3. POBLAMIENTO DE TABLAS (FASE 3)
   Población estricta de las 5 tablas indicadas en la pauta:
     1. REGION
     2. COMUNA
     3. ASOCIACION
     4. NACIONALIDAD
     5. CLUB_FUTBOL
   --------------------------------------------------------------------- */

-- 3.1 Poblamiento de REGION
-- Se incluyen regiones 8 y 16 porque COMUNA (Concepción y Chillán) las referencia,
-- asegurando el 100% de integridad referencial sin errores.
INSERT INTO region (id_region, nombre_region) VALUES (1,  'ARICA Y PARINACOTA Y TARAPACA');
INSERT INTO region (id_region, nombre_region) VALUES (2,  'ANTOFAGASTA');
INSERT INTO region (id_region, nombre_region) VALUES (3,  'ATACAMA Y COQUIMBO');
INSERT INTO region (id_region, nombre_region) VALUES (5,  'VALPARAISO');
INSERT INTO region (id_region, nombre_region) VALUES (8,  'BIOBIO');
INSERT INTO region (id_region, nombre_region) VALUES (13, 'METROPOLITANA');
INSERT INTO region (id_region, nombre_region) VALUES (16, 'ÑUBLE');

-- 3.2 Poblamiento de COMUNA
INSERT INTO comuna (id_comuna, nombre_comuna, id_region) VALUES (101, 'Santiago',    13);
INSERT INTO comuna (id_comuna, nombre_comuna, id_region) VALUES (102, 'Valparaíso',   5);
INSERT INTO comuna (id_comuna, nombre_comuna, id_region) VALUES (103, 'Concepción',   8);
INSERT INTO comuna (id_comuna, nombre_comuna, id_region) VALUES (104, 'Antofagasta',  2);
INSERT INTO comuna (id_comuna, nombre_comuna, id_region) VALUES (105, 'Chillán',      16);

-- 3.3 Poblamiento de ASOCIACION
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (25, 'Asociación de Fútbol de Santiago',       TO_DATE('15-05-2001','DD-MM-YYYY'), 'P');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (26, 'Asociación Nacional de Fútbol Amateur',  TO_DATE('10-03-1998','DD-MM-YYYY'), 'A');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (27, 'Asociación de Fútbol de Valparaíso',     TO_DATE('21-07-1987','DD-MM-YYYY'), 'P');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (28, 'Asociación de Fútbol de Concepción',     TO_DATE('30-11-1995','DD-MM-YYYY'), 'A');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (29, 'Asociación de Fútbol de Antofagasta',    TO_DATE('25-06-2003','DD-MM-YYYY'), 'P');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (30, 'Asociación de Fútbol de Temuco',         TO_DATE('12-01-2010','DD-MM-YYYY'), 'A');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (31, 'Asociación de Fútbol de Rancagua',       TO_DATE('08-09-1999','DD-MM-YYYY'), 'P');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (32, 'Asociación de Fútbol de Puerto Montt',   TO_DATE('20-04-2005','DD-MM-YYYY'), 'A');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (33, 'Asociación de Fútbol de La Serena',      TO_DATE('14-08-2012','DD-MM-YYYY'), 'P');
INSERT INTO asociacion (id_asociacion, nombre_asociacion, fecha_creacion, tipo_asociacion)
VALUES (34, 'Asociación de Fútbol de Chillán',        TO_DATE('01-12-2018','DD-MM-YYYY'), 'A');

-- 3.4 Poblamiento de NACIONALIDAD
-- La columna IDENTITY genera automáticamente los valores: 210, 212, 214, 216, 218
INSERT INTO nacionalidad (descripcion) VALUES ('Chilena');
INSERT INTO nacionalidad (descripcion) VALUES ('Argentina');
INSERT INTO nacionalidad (descripcion) VALUES ('Peruana');
INSERT INTO nacionalidad (descripcion) VALUES ('Boliviana');
INSERT INTO nacionalidad (descripcion) VALUES ('Brasileña');

-- 3.5 Poblamiento de CLUB_FUTBOL
-- La secuencia seq_club_futbol genera: 703, 707, 711, 715, 719
INSERT INTO club_futbol (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES (seq_club_futbol.NEXTVAL, 'Colo-Colo',            500000000, 'Av. Marathon 5300',                'Profesional');
INSERT INTO club_futbol (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES (seq_club_futbol.NEXTVAL, 'Universidad de Chile', 450000000, 'Av. El Parrón 0931',               'Profesional');
INSERT INTO club_futbol (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES (seq_club_futbol.NEXTVAL, 'Deportes Antofagasta', 180000000, 'Avenida Angamos 01606',            'Profesional');
INSERT INTO club_futbol (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES (seq_club_futbol.NEXTVAL, 'Huachipato',           220000000, 'Avenida Desiderio García 909',     'Profesional');
INSERT INTO club_futbol (id_club, nombre_club, patrimonio, ubicacion_calle, tipo_club)
VALUES (seq_club_futbol.NEXTVAL, 'Ñublense',             170000000, 'Avenida Pedro Aguirre Cerda 1003', 'Profesional');

COMMIT;

/* ---------------------------------------------------------------------
   4. RECUPERACIÓN DE INFORMACIÓN MEDIANTE CONSULTAS SQL (FASE 4)
   --------------------------------------------------------------------- */

-- 4.1 Informe 1: Asociaciones de fútbol profesional
-- Condiciones:
--   - Tipo profesional (P)
--   - Creadas después del año 2000 (fecha_creacion > 31-12-2000)
--   - Ordenadas de manera descendente según su fecha de creación
-- Formato esperado: ASOCIACION | CREADA | TIPO (Figura 3)
SELECT 'ID:' || id_asociacion || ' * ' || nombre_asociacion AS "ASOCIACION",
       TO_CHAR(fecha_creacion, 'DD-MM-YYYY')                AS "CREADA",
       tipo_asociacion                                      AS "TIPO"
FROM   asociacion
WHERE  tipo_asociacion = 'P'
  AND  fecha_creacion > TO_DATE('31-12-2000','DD-MM-YYYY')
ORDER BY fecha_creacion DESC;

-- 4.2 Informe 2: Patrimonio de clubes de fútbol
-- Condiciones:
--   - Nombre contenga la letra 'a' (mayúscula o minúscula, o con tilde)
--   - Patrimonio superior a $200.000.000
--   - Tipo profesional
--   - Tipo de cambio de $955 por dólar
--   - Ordenados de manera descendente según el código del club
-- Formato esperado: CLUB | NOMBRE CLUB | PATRIMONIO EN PESOS | PATRIMONIO EN DOLARES (Figura 4)
SELECT id_club              AS "CLUB",
       nombre_club          AS "NOMBRE CLUB",
       patrimonio           AS "PATRIMONIO EN PESOS",
       patrimonio / 955     AS "PATRIMONIO EN DOLARES"
FROM   club_futbol
WHERE  (UPPER(nombre_club) LIKE '%A%' OR UPPER(nombre_club) LIKE '%Á%')
  AND  patrimonio > 200000000
  AND  tipo_club = 'Profesional'
ORDER BY id_club DESC;